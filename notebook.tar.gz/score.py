#!/usr/bin/env python
# coding: utf-8
# %%

# %%


import os
import json
import pickle

import pandas as pd
from sklearn.externals import joblib


def init():
    global model_my
    print("am in init")
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'automl_model.pkl')
    #model_path=os.getenv('AZUREML_MODEL_DIR')
    print (model_path)
    #with open(model_path, 'rb') as f:
    model_my = joblib.load(model_path)

def run(data):
    try:
        data = json.loads(data)
        data = data["data"]
        data = pd.DataFrame(data)
        result = model_my.predict(data)
        # You can return any data type, as long as it is JSON serializable.
        return json.dumps({"result": result.tolist()})
    except Exception as e:
        return json.dumps({"error": str(e)})

